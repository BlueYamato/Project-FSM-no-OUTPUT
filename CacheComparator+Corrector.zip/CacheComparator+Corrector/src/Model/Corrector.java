/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Itsuka Kotori
 */
public class Corrector {

    public int[] correct(Comparator comp) {
//        int[] dataBitRec = comp.getDataBitRec();
//        ArrayList<Integer> syndrome = comp.getErrorIndex();
//        for(int i = syndrome.size() - 1; i >= 0; i--){
//            int dataIndex = toDecimal(syndrome.get(i));
//            if(dataBitRec[12 - dataIndex] == 0){
//                comp.setDataBitRec(12-dataIndex, 1);
//            }
//            else{
//                comp.setDataBitRec(12-dataIndex, 0);
//            }
//        }
//        System.out.println(Arrays.toString(comp.getDataBitRec()));
        int[] dataBitRec = comp.getDataBitRec();
        int[] syndrome = comp.getSyndrome();
        String syndromeInString = "";
        for (int i = 0; i < syndrome.length; i++) {
            syndromeInString += syndrome[i];
        }
        int fixSyndrome = Integer.parseInt(syndromeInString);
        int index = toDecimal(fixSyndrome) - 1;
        if (index >= 0) {
            if (dataBitRec[index] == 1) {
                dataBitRec[index] = 0;
            } else {
                dataBitRec[index] = 1;
            }
        }
        int[] checkBit = comp.getcheckBit();
        dataBitRec[11] = checkBit[0];
        dataBitRec[10] = checkBit[1];
        dataBitRec[8] = checkBit[2];
        dataBitRec[4] = checkBit[3];
        return dataBitRec;
    }

    private int toDecimal(int x) {
        int result = 0;
        int pow = 0;
        while (x != 0) {
            int y = x % 10;
            result += y * (int) Math.pow(2, pow);
            pow++;
            x = x / 10;
        }
        return result;
    }
}
